### SS6PlayerForCocos2d-x

ドキュメントはこちらです。  
https://github.com/SpriteStudio/SS6PlayerForCocos2d-x/wiki
